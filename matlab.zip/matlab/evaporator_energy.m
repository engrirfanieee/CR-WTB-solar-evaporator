function r = evaporator_energy(p, A_eff, phi_ch, q_sun, Nu_ch)
%EVAPORATOR_ENERGY  Steady 1-D energy balance of a floating 2-D evaporator.
%   A*q = m*h_lv + m*c_pw*(Ts-Tb) + e*sig*(Ts^4-Ta^4) + h_c*(Ts-Ta) + U_core*(Ts-Tb)
%   m = h_m*(a_w*rho_v,sat(Ts) - RH*rho_v,sat(Ta)), h_m from Chilton-Colburn.
%   The second term heats the feed water from Tb to Ts. U_core combines the
%   foam core and laminate ballast in series, in parallel with the water-filled
%   channels (effective conductivity Nu_ch*k_w) that run through both.
if nargin < 4 || isempty(q_sun), q_sun = p.q_sun; end
if nargin < 5 || isempty(Nu_ch), Nu_ch = 1; end
sig = 5.670374419e-8; Mw = 0.018015; Ru = 8.314;
rho_v = @(T) psat_water(T) * Mw ./ (Ru * T);
h_lv  = @(T) 2.501e6 - 2370 * (T - 273.15);
h_m   = p.h_c / (p.rho_air * p.cp_air * p.Le^(2/3));
% water-filled channels run through the foam core and the perforated ballast plate;
% the solid path is foam and laminate in series
L_ch = p.L_core + p.t_bal;
U_core = phi_ch * Nu_ch * p.k_w / L_ch + (1 - phi_ch) / (p.L_core / p.k_foam + p.t_bal / p.k_lam);
mfun = @(T) h_m * (p.a_w * rho_v(T) - p.RH * rho_v(p.T_amb));
if isempty(p.q_cond_fixed), qc = @(T) U_core*(T - p.T_bulk); else, qc = @(T) p.q_cond_fixed; end
f = @(T) A_eff*q_sun - mfun(T).*(h_lv(T) + p.c_pw*max(T - p.T_bulk, 0)) ...
         - p.emis*sig*(T.^4 - p.T_amb^4) - p.h_c*(T - p.T_amb) - qc(T);
Ts = fzero(f, [p.T_amb - 30, p.T_amb + 80]);
r.Ts = Ts; r.m = mfun(Ts); r.m_h = r.m * 3600;
r.q_evap = r.m * h_lv(Ts);
r.q_sens = r.m * p.c_pw * max(Ts - p.T_bulk, 0);
r.q_rad  = p.emis*sig*(Ts^4 - p.T_amb^4);
r.q_conv = p.h_c*(Ts - p.T_amb);
r.q_cond = qc(Ts);
r.q_refl = (1 - A_eff) * q_sun;
r.U_core = U_core; r.h_m = h_m;
r.eta = r.q_evap / max(q_sun, eps);
end
