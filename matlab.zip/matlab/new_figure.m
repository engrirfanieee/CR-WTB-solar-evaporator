function f = new_figure()
%NEW_FIGURE  Two-panel figure of 18 cm x 8.5 cm (double-column width).
f = figure('Units', 'centimeters', 'Position', [2 2 18 8.5], 'Color', 'w', ...
           'PaperUnits', 'centimeters', 'PaperPosition', [0 0 18 8.5], 'PaperSize', [18 8.5]);
end
