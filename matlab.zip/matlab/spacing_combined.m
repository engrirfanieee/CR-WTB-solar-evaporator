function [s, dW, ok] = spacing_combined(p, d_ch)
%SPACING_COMBINED  Channel spacing for which the combined adverse case keeps the
%peak absorber salinity at gypsum onset (no further margin). The adverse case
%(p.adv) combines a sixteen-fold critical Rayleigh number, a denser and more
%tortuous absorber, an exchange flow weaker than any sampled value and a
%uniform loss of a fraction of the channels (effective spacing s/sqrt(1-b)).
pW = adverse_params(p); b = p.adv.block;
g = @(sp) evaluate_design(pW, d_ch, sp / sqrt(1 - b)).sd.c_mid - p.CF_gyp * p.S0;
ok = true; s = NaN; dW = [];
try
    s = fzero(g, [1.3 * d_ch, 12e-3]);
    dW = evaluate_design(pW, d_ch, s / sqrt(1 - b));
    ok = ~dW.dry && dW.ch.f_S <= p.fS_max;
catch
    ok = false;
end
end
