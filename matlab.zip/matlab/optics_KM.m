function [A_eff, out] = optics_KM(p, delta, L_a)
%OPTICS_KM  Solar-weighted absorptance of a char-coated glass-fibre mat.
%   Geometric-optics extinction of randomly oriented cylinders,
%   beta = (1-eps)/d (mean projected area S/4 per unit volume), combined with a
%   Kubelka-Munk two-flux solution for a finite layer over a backing of
%   reflectance R_g, weighted by the ASTM G173-03 AM1.5G spectrum. Absorption per fibre interception is set by a char coat
%   of thickness delta with extinction coefficient k_c (double-pass path 2*delta).
if nargin < 3, L_a = p.L_a; end
lam = p.lambda;
w = solar_weights(p, lam);
d = p.d_f + 2*delta;
beta = (1 - p.eps_a) / d;                          % extinction coefficient [1/m]
r_c = ((p.n_c - p.n_w)^2 + p.k_c^2) / ((p.n_c + p.n_w)^2 + p.k_c^2); % char/water Fresnel
R_s = ((p.n_w - 1) / (p.n_w + 1))^2;               % air/water interface
a1 = 1 - exp(-(4*pi*p.k_c ./ lam) * 2 * delta);    % single-pass absorption in coat
a_i = (1 - r_c) .* a1;                             % absorbed fraction per interception
K = 2 * beta .* a_i;
S = beta .* (1 - a_i);
A_layer = zeros(size(lam));
for j = 1:numel(lam)
    if K(j) < 1e-9
        A_layer(j) = 0; continue
    end
    a = 1 + K(j) / S(j);
    b = sqrt(a^2 - 1);
    Y = b * S(j) * L_a;
    den = a * sinh(Y) + b * cosh(Y);
    if ~isfinite(den)          % optically very thick layer
        R0 = a - b; T0 = 0;
    else
        R0 = sinh(Y) / den;
        T0 = b / den;
    end
    A0 = 1 - R0 - T0;
    A_layer(j) = A0 * (1 + T0 * p.R_g / (1 - R0 * p.R_g));
end
A_spec = (1 - R_s) * A_layer;
A_eff = trapz(lam, w .* A_spec);
out.A_spec = A_spec; out.beta = beta; out.r_c = r_c; out.R_s = R_s; out.lambda = lam;
end
