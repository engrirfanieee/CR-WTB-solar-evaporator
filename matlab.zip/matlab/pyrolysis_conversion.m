function [alpha, t, T] = pyrolysis_conversion(p, T_hold, t_hold)
%PYROLYSIS_CONVERSION  Resin conversion during a ramp-and-hold pyrolysis.
%   Single-step model d(alpha)/dt = A exp(-Ea/RT) (1-alpha)^n.
%   The furnace ramps from 25 C at p.beta_ramp to T_hold [K] and holds for
%   t_hold [s]. Returns the conversion history alpha(t) and temperature T(t).
R = 8.314;
A = pre_exponential(p);
T0 = 298.15;
t_ramp = max(T_hold - T0, 0) / p.beta_ramp;
nr = 2000; nh = 1000;
t1 = linspace(0, t_ramp, nr);
T1 = T0 + p.beta_ramp * t1;
if t_hold > 0
    t2 = t_ramp + linspace(t_ramp/nr, t_hold, nh);
    T2 = T_hold * ones(size(t2));
else
    t2 = []; T2 = [];
end
t = [t1, t2];
T = [T1, T2];
k = A * exp(-p.Ea ./ (R * T));
if abs(p.n_rxn - 1) < 1e-12
    I = cumtrapz_local(t, k);
    alpha = 1 - exp(-I);
else
    I = cumtrapz_local(t, k);
    alpha = 1 - max(1 - (1 - p.n_rxn) * I, 0).^(1 / (1 - p.n_rxn));
end
end

function A = pre_exponential(p)
% Kissinger condition for a first-order peak: beta*Ea/(R*Tp^2) = A*exp(-Ea/(R*Tp))
R = 8.314;
A = p.beta_ref * p.Ea / (R * p.Tpeak_ref^2) * exp(p.Ea / (R * p.Tpeak_ref));
end

function I = cumtrapz_local(t, y)
I = [0, cumsum(0.5 * (y(1:end-1) + y(2:end)) .* diff(t))];
end
