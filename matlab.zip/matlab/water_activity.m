function aw = water_activity(S)
%WATER_ACTIVITY  Water activity of an NaCl solution of S wt% at 25 C, from the
%osmotic coefficient phi tabulated by Robinson and Stokes (1959):
%   ln(aw) = -2*m*phi*M_w,  m = (S/58.44)/(1 - S/100)*10 mol kg^-1.
%NaCl is used as a surrogate for sea salt (at 3.5 wt% it gives aw = 0.979).
m_tab   = [0 0.1 0.2 0.5 1.0 1.5 2.0 3.0 4.0 5.0 6.0];
phi_tab = [1 0.932 0.925 0.921 0.936 0.958 0.983 1.045 1.116 1.192 1.271];
m = (S ./ 58.44) ./ (1 - S/100) * 10;
phi = interp1(m_tab, phi_tab, min(m, 6.0), 'pchip');
aw = exp(-2 * m .* phi * 0.018015);
end
