function b = ballast_stack(p, phi)
%BALLAST_STACK  Perforated laminate ballast plate bonded below the foam core.
%   The feed channels are drilled through the bonded core-ballast stack, so the
%   plate has the same channel area fraction phi. With the bottom of the
%   absorber at the waterline (zero freeboard), the weight of the wet absorber,
%   the wet core and the ballast equals the weight of seawater displaced by the
%   solid core and plate:
%     m_abs + m_core,wet + rho_lam*t_b*(1-phi) = rho_sw*(L_core + t_b)*(1-phi)
%   Water uptake u of the foam is a volume fraction: m_core,wet = m_core + u*rho_w*L_core*(1-phi).
w_r = 1 - p.w_f;
rho_solid = 1 / (p.w_f/(p.w_f + w_r*p.Yc) / p.rho_f + (w_r*p.Yc)/(p.w_f + w_r*p.Yc) / p.rho_c);
b.m_abs_dry = (1 - p.eps_a) * p.L_a * rho_solid;
b.m_abs_wet = b.m_abs_dry + p.eps_a * p.L_a * 1000;
b.m_core = p.rho_core * p.L_core * (1 - phi);
b.m_core_wet = b.m_core + p.uptake * 1000 * p.L_core * (1 - phi);
b.freeboard_noballast = p.L_core - (b.m_abs_wet + b.m_core_wet) / (p.rho_sw * (1 - phi));
b.t_bal = max(0, (p.rho_sw * p.L_core * (1 - phi) - b.m_abs_wet - b.m_core_wet) / ((p.rho_lam - p.rho_sw) * (1 - phi)));
b.m_bal = p.rho_lam * b.t_bal * (1 - phi);
b.L_ch = p.L_core + b.t_bal;
end
