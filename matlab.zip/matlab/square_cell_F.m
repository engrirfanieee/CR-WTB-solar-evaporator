function F = square_cell_F(rho0)
%SQUARE_CELL_F  Dimensionless peak potential of the exact square unit cell.
%   In the absorber the Darcy pore velocity is a potential flow, u = -grad(Phi),
%   with lap(Phi) = m/(rho*eps*L_a) (uniform evaporation sink). With zero net
%   salt flux everywhere, c = c_top*exp((Phi_ch - Phi)/D_eff) is the exact
%   solution, so the peak salinity at the cell corner follows from the
%   potential difference between the channel edge and the corner.
%   Quarter cell [0,1]^2 scaled by s/2, channel (radius rho0 = r0/(s/2)) at the
%   origin with psi = 0, zero normal gradient on all straight edges,
%   lap(psi) = 1. Returns F = -psi(1,1) >= 0, so that
%      Pe_sq = m*(s/2)^2*F/(rho*eps*L_a*D_eff).
%   Values are tabulated once by finite differences (n = 320; grid change from
%   160 to 320 alters F by <1%) and interpolated.
persistent R0 FF
if isempty(R0)
    R0 = [0.03 0.05:0.025:0.85];
    FF = zeros(size(R0));
    for k = 1:numel(R0), FF(k) = solve_cell(R0(k), 320); end
end
F = interp1(R0, FF, min(max(rho0, R0(1)), R0(end)), 'pchip');
end

function F = solve_cell(r0, n)
h = 1 / n; [X, Y] = meshgrid(0:h:1, 0:h:1); X = X'; Y = Y';
N = (n + 1)^2; id = reshape(1:N, n + 1, n + 1);
dir = (X.^2 + Y.^2) <= r0^2;
I = zeros(5*N, 1); J = I; V = I; b = ones(N, 1) * h^2; c = 0;
for i = 1:n+1
    for j = 1:n+1
        p = id(i, j);
        if dir(i, j)
            c = c + 1; I(c) = p; J(c) = p; V(c) = 1; b(p) = 0; continue
        end
        nb = [i-1 j; i+1 j; i j-1; i j+1];
        c = c + 1; I(c) = p; J(c) = p; V(c) = -4;
        for q = 1:4
            ii = nb(q, 1); jj = nb(q, 2);
            if ii < 1, ii = 2; end, if ii > n+1, ii = n; end      % mirror (Neumann)
            if jj < 1, jj = 2; end, if jj > n+1, jj = n; end
            c = c + 1; I(c) = p; J(c) = id(ii, jj); V(c) = 1;
        end
    end
end
A = sparse(I(1:c), J(1:c), V(1:c), N, N);
psi = A \ b;
F = -psi(id(n+1, n+1));
end
