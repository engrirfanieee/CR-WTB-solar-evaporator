function d = evaluate_design(p, d_ch, s, Nu0)
%EVALUATE_DESIGN  Performance and feasibility of a fixed geometry (channel
%diameter d_ch, spacing s). The energy balance and the channel model are
%iterated because Nu_ch depends on the exchange velocity, which depends on
%the evaporation flux.
c = char_coating(p, 1.0);
A = optics_KM(p, c.delta, p.L_a);
phi = min(pi * d_ch^2 / (4 * s^2), 0.5);
if nargin < 4 || isempty(Nu0), Nu0 = 1; end
bal = ballast_stack(p, phi); p.t_bal = bal.t_bal;     % perforated ballast plate
Nu = Nu0; dNu = NaN; pl = p; daw = 0;           % pl: illuminated state (salinity-dependent a_w)
for it = 1:300
    e = evaporator_energy(pl, A, phi, [], Nu);
    ch = channel_model(p, e.m, d_ch, s, e.Ts);
    sd = salt_design(p, e.m, p.L_a, d_ch, s, ch.f_S);
    if p.aw_mode
        aw_new = water_activity(min(sd.c_mean, p.S_sat));   % brine cannot exceed saturation daw = abs(aw_new - pl.a_w);
        pl.a_w = 0.5 * pl.a_w + 0.5 * aw_new;
    end
    dNu = abs(ch.Nu - Nu);
    if dNu < 1e-10 && daw < 1e-12, break; end
    Nu = 0.5 * Nu + 0.5 * ch.Nu;
end
d.iter = it; d.dNu = dNu; d.daw = daw; d.p = p; d.bal = bal; d.a_w = pl.a_w;
dark = evaporator_energy(p, A, phi, 0, 1);       % dark rate at the feed salinity (a_w of seawater)
d.t_abs_diff = (s/2)^2 * p.tau / p.D_salt;       % salt diffusion over half a spacing in the absorber
d.t_abs_res = p.eps_a * p.L_a * 1000 / e.m;      % residence time of water in the absorber
d.d_ch = d_ch; d.s_sp = s; d.phi = phi; d.c = c; d.A = A; d.e = e; d.dark = dark; d.ch = ch; d.sd = sd;
d.cap = capillary_check(p, c.delta, e.m, s, p.L_a);
d.m_net_h = e.m_h - dark.m_h;
d.eta_net = (e.m - dark.m) * (2.501e6 - 2370*(e.Ts-273.15)) / p.q_sun;
d.dry = ~d.cap.ok;
d.operable = ~d.dry && ~sd.crystallises;                         % physical criterion
d.feasible = d.operable && sd.c_mid <= sd.c_lim * (1 + 1e-9) && ch.f_S <= p.fS_max; % design criterion
end
