function [best, tab] = optimise_combined(p)
%OPTIMISE_COMBINED  Recommended design: for each channel diameter the spacing is
%set so that the combined adverse case just reaches gypsum onset
%(spacing_combined); among diameters whose adverse case also keeps f_S <= fS_max,
%the one with the highest net evaporation rate at baseline parameters wins.
n = numel(p.d_grid);
tab = struct('d', num2cell(p.d_grid), 's', NaN, 'net', NaN, 'fSW', NaN, 'feasible', false);
best = []; bestnet = -Inf;
for i = 1:n
    [s, dW, ok] = spacing_combined(p, p.d_grid(i));
    if isnan(s), continue; end
    d = evaluate_design(p, p.d_grid(i), s);
    tab(i).s = s; tab(i).net = d.m_net_h; tab(i).fSW = dW.ch.f_S; tab(i).feasible = ok && d.feasible;
    if tab(i).feasible && d.m_net_h > bestnet, best = d; bestnet = d.m_net_h; end
end
end
