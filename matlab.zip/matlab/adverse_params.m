function pW = adverse_params(p)
%ADVERSE_PARAMS  Parameter set of the combined adverse case (Section 3.8).
pW = p; pW.Ra_c = p.adv.Ra_c; pW.eps_a = p.adv.eps_a; pW.tau = p.adv.tau; pW.C_ex = p.adv.C_ex;
end
