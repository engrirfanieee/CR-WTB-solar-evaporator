Char-retentive WTB solar evaporator model - MATLAB code (revised version)
=========================================================================
Written in MATLAB (core functions only, no toolboxes). Runs in MATLAB R2022b and GNU Octave 8.4.0.
The values reported in the article were generated with GNU Octave 8.4.0 on Linux; re-running this
package there from a clean copy reproduces them exactly. MATLAB and Octave may produce different
random-number streams from the same seed (rng(42) / rand('state', 7)), so Monte Carlo samples
obtained in MATLAB need not coincide with those reported. Run:
    >> cd matlab
    >> main_CR_WTB_evaporator
Outputs: ../figures/Figure_2.png ... Figure_7.png (600 dpi) and results.txt
(all numbers of the text and of Tables 4, 5, 6, 7 and 8)
Runtime: about 15 min on two cores (two design screenings, verification, model-form scenarios, three Monte Carlo sets of 1000 samples). Seed fixed (rng(42)).
The 5000-sample convergence check (Section 4.6): >> convergence_check   (writes convergence_results.txt; about 10 min).
am15g.csv must be in the same folder (ASTM G173-03 AM1.5G global spectrum,
300-2500 nm; columns: wavelength [nm], spectral irradiance [W m^-2 nm^-1]).

Files
  main_CR_WTB_evaporator.m  driver; reproduces every number, table entry and Figs. 2-7
  convergence_check.m       5000-sample Monte Carlo convergence check (Section 4.6)
  params_default.m          all parameters (assumptions labelled)
  mc_ranges.m               Monte Carlo ranges: 'wide' (Table 3) and 'relative' (+/-25 %)
  prctile_local.m           percentile without toolboxes
  pyrolysis_conversion.m    Eqs. (1)-(2)   resin conversion, ramp + hold
  window_low.m              lowest hold temperature reaching alpha >= 0.99 (Table 4)
  char_coating.m            Eqs. (3)-(4)   char loading and coat thickness
  solar_weights.m           AM1.5G (or blackbody) spectral weights
  optics_KM.m               Eqs. (5)-(9)   Kubelka-Munk absorptance of char-coated mat
  evaporator_energy.m       Eqs. (10)-(13) energy balance incl. feed-water heating; dark rate
  psat_water.m              Buck saturation vapour pressure
  salt_design.m             Eqs. (14)-(17), (B.5) square cell, radial bounds, 1-D strip; NaCl and gypsum limits
  square_cell_F.m           Eq. (B.3) corner potential F of the square cell (finite differences, tabulated)
  channel_model.m           Eqs. (18)-(22) salt-conserving exchange-flow brine return (continuous or
                            intermittent convection), f_S, convecting fraction xi, Nu_ch, Ra
  ballast_stack.m           Eqs. (24)-(25) perforated ballast plate, freeboard, channel length
  capillary_check.m         Eq. (23) capillary supply limit, dry-out flag, theta_max
  evaluate_design.m         performance and feasibility of a fixed geometry (fixed-point iteration)
  spacing_for_diameter.m    Eq. (17) spacing from the exact-cell salt criterion
  optimise_design.m         grid search over channel diameter under constraints (Section 3.8)
  screening_balance.m       Eq. (26) heat self-sufficiency, illustrative water yield, material accounting incl. ballast
  spacing_combined.m        spacing at which the combined adverse case reaches gypsum onset (Section 3.8)
  adverse_params.m          parameter set of the combined adverse case
  optimise_combined.m       recommended design (robust to the combined adverse case)
  water_activity.m          water activity of brine from NaCl osmotic coefficients (Eq. 11)
  verify_absorber_pde.m     independent finite-difference check of the analytical absorber solution (Table 6)
  rank_corr.m               Spearman rank correlation (no toolbox)
  cmap_seq.m, new_figure.m, fprintf_both.m  plotting/printing helpers
Figure 1 (schematic) is drawn by ../figure1/fig1.py (Python 3, Matplotlib): python3 fig1.py 17.1
(the argument is the ballast thickness in mm from results.txt).
