function ch = channel_model(p, m_flux, d_ch, s, Ts)
%CHANNEL_MODEL  Salt and heat transport in one open feed channel.
%   Mean upward feed velocity v = m*s^2/(rho*pi*r0^2). Brine returns by a
%   buoyancy-driven exchange flow: a descending stream (salinity c0 + dc) and a
%   rising stream (c0), each over half the cross-section, with velocities U and
%   U + 2v. Zero net salt flux gives 2*v*c0 = U*dc. With the viscous velocity
%   scale U = a_ex*dc, a_ex = g*beta_S*r0^2/(C_ex*nu):
%      dc_ex = sqrt(2*v*c0/a_ex).
%   The exchange needs an unstable stratification. Heat diffuses across the
%   channel far faster than salt, so the salt-finger criterion applies:
%      Ra = g*r0^4/nu*(beta_S*dS/dz/D - beta_T*dT/dz/kappa) >= Ra_c.
%   If dc_ex is too small for onset, salt accumulates at the channel top until
%   Ra = Ra_c, so the channel self-regulates:  dc = max(dc_ex, dc_onset).
%   In the onset-limited regime the column convects intermittently: salinity
%   builds up to dc_on, a burst of exchange flow at U_conv = a_ex*dc removes it,
%   and the column restabilises. Salt conservation fixes the time-mean exchange
%   velocity, U_mean = 2*v*c0/dc, and the convecting fraction of time
%   xi = U_mean/U_conv (= 1 when not onset-limited). dc_on plus an overshoot
%   allowance (chi, below) is the upper envelope of the cycle and is used for
%   the absorber feed salinity.
%   Heat: time-averaged Taylor dispersion, Nu_ch = 1 + xi*(U_conv*r0/kappa)^2/48.
%   The channel length is L_core + t_bal (perforated ballast plate).
rho = 1000; r0 = d_ch / 2; c0 = p.S0;
ch.v = m_flux * s^2 / (rho * pi * r0^2);
a_ex = p.g * p.beta_S * r0^2 / (p.C_ex * p.nu_w);        % m/s per wt%
ch.dc_ex = sqrt(2 * ch.v * c0 / a_ex);
L = p.L_core + p.t_bal; ch.L = L;
dTdz = max(Ts - p.T_bulk, 0) / L;
ch.Ra_T = p.g * p.beta_T * dTdz * r0^4 / (p.nu_w * p.kappa_w);
ch.dc_on = (p.Ra_c + ch.Ra_T) * p.nu_w * p.D_salt * L / (p.g * p.beta_S * r0^4);
ch.onset_limited = ch.dc_on > ch.dc_ex;
ch.dc = max(ch.dc_ex, ch.dc_on);
ch.f_S_on = 1 + ch.dc / c0;
ch.U_conv = a_ex * ch.dc;                        % exchange velocity while convecting
ch.U = 2 * ch.v * c0 / ch.dc;                    % time-mean exchange velocity (salt balance)
ch.xi = ch.U / ch.U_conv;                     % convecting fraction of time
ch.U_over_v = ch.U / ch.v;
ch.salt_residual = (ch.U * ch.dc - 2 * ch.v * c0) / (2 * ch.v * c0);
ch.Nu = 1 + ch.xi * (ch.U_conv * r0 / p.kappa_w)^2 / 48;
ch.t_heat = r0^2 / p.kappa_w; ch.t_salt = r0^2 / p.D_salt; ch.t_transit = L / ch.U_conv;
% intermittent regime: one burst ~ one transit time, so the cycle period is
% t_transit/xi. Salt keeps accumulating while a new burst grows; the growth time
% is bounded by the radial salt-diffusion time t_salt, which gives an overshoot
% allowance chi = t_salt/T_cyc on top of dc_on (zero for continuous convection).
ch.T_cyc = ch.t_transit / ch.xi;
if ch.onset_limited, ch.chi = ch.t_salt / ch.T_cyc; else, ch.chi = 0; end
ch.dc_env = ch.dc * (1 + ch.chi);               % upper envelope of channel-top excess
ch.f_S = 1 + ch.dc_env / c0;                     % used for the absorber and the f_S limit
ch.Ra_S = p.g * p.beta_S * (ch.dc / L) * r0^4 / (p.nu_w * p.D_salt);
ch.Ra = ch.Ra_S - ch.Ra_T;
ch.R_rho = p.beta_T * dTdz / (p.beta_S * ch.dc / L);
end
