function [s_design, s_max, ok] = spacing_for_diameter(p, d_ch)
%SPACING_FOR_DIAMETER  Largest spacing s_max for which the peak salinity of the
%exact square cell stays at the design limit min(psi*c_sat, CF_gyp*c0), iterated with the energy balance; the
%design spacing is s_frac*s_max.
target = log(min(p.margin * p.S_sat, p.CF_gyp * p.S0) / p.S0);
s = 4e-3; ok = true; s_max = NaN;
for it = 1:40
    d = evaluate_design(p, d_ch, s);
    g = @(sp) log(channel_model(d.p, d.e.m, d_ch, sp, d.e.Ts).f_S) + ...
              salt_design(p, d.e.m, p.L_a, d_ch, sp, 1).Pe_sq - target;
    lo = 1.2 * d_ch; hi = 40e-3;
    if g(lo) > 0, ok = false; s_design = NaN; return; end
    if g(hi) < 0, s_max = hi; else, s_max = fzero(g, [lo hi]); end
    s_new = p.s_frac * s_max;
    if abs(s_new - s) < 1e-8, s = s_new; break; end
    s = s_new;
end
s_design = s;
end
