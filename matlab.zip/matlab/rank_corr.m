function rho = rank_corr(X, y)
%RANK_CORR  Spearman rank correlation of each column of X with y (no toolbox).
n = size(X, 1);
ry = ranks(y(:));
rho = zeros(1, size(X, 2));
for j = 1:size(X, 2)
    rx = ranks(X(:, j));
    rho(j) = sum((rx - mean(rx)) .* (ry - mean(ry))) / ...
             sqrt(sum((rx - mean(rx)).^2) * sum((ry - mean(ry)).^2));
end
end
function r = ranks(v)
[~, idx] = sort(v);
r = zeros(size(v)); r(idx) = (1:numel(v))';
end
