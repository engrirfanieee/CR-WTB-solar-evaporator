function sd = salt_design(p, m_flux, L_a, d_ch, s, f_S)
%SALT_DESIGN  Peak salinity in the absorber of a square channel array.
%   Exact square unit cell (potential-flow solution, square_cell_F), bracketed
%   by two radial cells: equal-area circle R = s/sqrt(pi) (lower bound) and
%   circumscribed circle R = s/sqrt(2) (upper bound),
%     Pe_rad = m/(2*rho*eps*L_a*D_eff)*[R^2*ln(R/r0) - (R^2 - r0^2)/2],
%   and the 1-D strip m*s^2/(8*rho*eps*L_a*D_eff) for comparison (Appendix B).
%   c_top = f_S*c0 is the salinity delivered at the channel top.
rho = 1000; r0 = d_ch / 2;
% u is the interstitial (pore) velocity, so continuity carries 1/eps_a and the
% dispersion coefficient is the pore-scale value D/tau (salt flux per unit pore
% area). Written with the superficial velocity q = eps_a*u and the bulk
% coefficient eps_a*D/tau, the equation is identical (Appendix B).
D_eff = p.D_salt / p.tau;
G = m_flux / (rho * p.eps_a * L_a * D_eff);
rad = @(R) G/2 * (R^2 * log(R / r0) - (R^2 - r0^2) / 2);
sd.D_eff = D_eff;
sd.Pe_sq    = G * (s/2)^2 * square_cell_F(r0 / (s/2));
sd.Pe_upper = rad(s / sqrt(2));
sd.Pe_lower = rad(s / sqrt(pi));
sd.Pe_strip = G * s^2 / 8;
c_top = f_S * p.S0;
sd.c_mid = c_top * exp(sd.Pe_sq);
sd.c_mid_upper = c_top * exp(sd.Pe_upper);
sd.c_mid_lower = c_top * exp(sd.Pe_lower);
sd.c_mid_strip = c_top * exp(sd.Pe_strip);
% area-mean salinity of the evaporating surface (equal-area circle), used for
% the water activity of the evaporating brine
R = s / sqrt(pi); r = linspace(r0, R, 400);
cr = c_top * exp(G/2 * (R^2 * log(r / r0) - (r.^2 - r0^2) / 2));
sd.c_mean = trapz(r, cr .* r) / trapz(r, r);
sd.crystallises = sd.c_mid >= p.S_sat;            % NaCl saturation
sd.c_gyp = p.CF_gyp * p.S0;                        % onset of gypsum precipitation
sd.gypsum = sd.c_mid >= sd.c_gyp;
sd.c_lim = min(p.margin * p.S_sat, sd.c_gyp);      % design limit
end
