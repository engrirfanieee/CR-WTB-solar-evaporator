function p = params_default()
%PARAMS_DEFAULT  Baseline parameters for the char-retentive (CR) wind-turbine-
%blade (WTB) solar interfacial evaporator model.
%
% Every value is either a physical constant, a value reported in the cited
% literature, or an explicitly labelled ASSUMPTION that is varied in the
% Monte Carlo analysis (see mc_ranges.m). Units are SI unless noted.
%
% Compatible with MATLAB R2019b+ and GNU Octave 7+.

% ---------------- Laminate composition (GFRP shell of the blade) ----------
p.w_f      = 0.65;      % glass-fibre mass fraction [-] (60-70 wt% reported)
p.d_f      = 17e-6;     % E-glass filament diameter [m]       (ASSUMPTION)
p.rho_f    = 2550;      % E-glass density [kg m^-3]
p.rho_c    = 1500;      % pyrolytic char density [kg m^-3]    (ASSUMPTION)

% ---------------- Resin pyrolysis kinetics (single-step, first order) -----
p.Ea       = 150e3;     % activation energy [J mol^-1] (mid of 120-180 kJ/mol)
p.Tpeak_ref= 390+273.15;% DTG peak used to calibrate A at 10 K/min [K] (ASSUMPTION)
p.beta_ref = 10/60;     % reference heating rate [K s^-1]
p.n_rxn    = 1;         % reaction order [-]
p.Yc       = 0.15;      % char yield per unit resin mass [-]  (ASSUMPTION)
p.alpha_req= 0.99;      % required resin conversion (leaching guard) [-]
p.T_max_fibre = 450+273.15; % upper hold temperature to limit fibre damage [K]
p.beta_ramp= 10/60;     % furnace ramp in the process-window map [K s^-1]

% ---------------- Optics of char-coated fibre mat -------------------------
p.n_c      = 2.0;       % real refractive index of amorphous char  (ASSUMPTION)
p.k_c      = 0.6;       % extinction coefficient of char          (ASSUMPTION)
p.n_w      = 1.33;      % water refractive index
p.eps_a    = 0.80;      % porosity of the absorber (opened laminate) (ASSUMPTION)
p.L_a      = 2.0e-3;    % absorber thickness [m]
p.R_g      = 0.05;      % diffuse reflectance of the backing (wet core) [-]
p.lambda   = linspace(0.30e-6, 2.50e-6, 221); % wavelength grid [m]
p.T_sun    = 5778;      % blackbody temperature (only used if p.spectrum = 'BB') [K]
p.spectrum = 'AM15G';   % 'AM15G' (ASTM G173-03 global tilt, file am15g.csv) or 'BB'

% ---------------- Thermal / mass transfer ---------------------------------
p.q_sun    = 1000;      % irradiance [W m^-2] (1 sun)
p.T_amb    = 25+273.15; % ambient air [K]
p.T_bulk   = 25+273.15; % bulk seawater [K]
p.RH       = 0.50;      % relative humidity [-]
p.a_w      = 0.98;      % water activity of seawater (3.5 wt% NaCl) [-]; used when aw_mode = 0 and for dark evaporation
p.aw_mode  = 1;         % 1: water activity from the area-mean absorber salinity (water_activity.m); 0: fixed a_w
p.emis     = 0.95;      % IR emissivity of wet surface [-]
p.q_cond_fixed = [];    % if set [W m^-2], replaces U_core*(Ts-Tb) (benchmark only)
p.h_c      = 5;         % convective coefficient, still laboratory air (benchmark, Section 4.4) [W m^-2 K^-1]
p.h_c_out  = 10;        % convective coefficient outdoors, light wind (ASSUMPTION) [W m^-2 K^-1]
p.rho_air  = 1.18;      % [kg m^-3]
p.cp_air   = 1005;      % [J kg^-1 K^-1]
p.Le       = 0.85;      % Lewis number, water vapour in air [-]

% ---------------- Floating core (blade sandwich foam, reused) -------------
p.L_core   = 20e-3;     % core thickness [m]
p.k_foam   = 0.040;     % PVC/PET foam conductivity [W m^-1 K^-1] (ASSUMPTION)
p.k_w      = 0.60;      % water conductivity [W m^-1 K^-1]
p.d_ch     = 2.0e-3;    % feed-channel diameter drilled through core [m]
p.C_ex     = 100;       % geometric constant of the channel exchange-flow velocity scale (ASSUMPTION)
p.kappa_w  = 1.45e-7;   % thermal diffusivity of water [m^2 s^-1]
p.c_pw     = 3990;      % specific heat of seawater [J kg^-1 K^-1]

% ---------------- Salt transport --------------------------------------------
p.D_salt   = 1.5e-9;    % NaCl diffusivity in water at ~35 C [m^2 s^-1]
p.tau      = 1.2;       % tortuosity of absorber [-] (ASSUMPTION)
p.S0       = 3.5;       % feed salinity [wt%]
p.S_sat    = 26.4;      % NaCl saturation [wt%]
p.margin   = 0.80;      % NaCl design margin: c_mid <= margin*c_sat [-]
p.adv = struct('Ra_c', 1088, 'eps_a', 0.6, 'tau', 2.0, 'C_ex', 3000, 'block', 0.25);  % combined adverse case for the recommended design (Section 3.8)
p.CF_gyp   = 3.3;       % concentration factor at onset of gypsum precipitation from seawater (3.3-3.8, Reiss et al. 2021)
p.k_lam    = 0.35;      % through-thickness conductivity of GFRP laminate ballast [W m^-1 K^-1] (ASSUMPTION)
p.t_bal    = 0;         % thickness of perforated laminate ballast below the core [m] (set by evaluate_design)
p.beta_S   = 0.0076;    % relative density increase per wt% salinity [-/wt%]
p.nu_w     = 0.8e-6;    % kinematic viscosity of water at ~30 C [m^2 s^-1]
p.Ra_c     = 68;        % critical Rayleigh number, vertical tube, insulating wall (Yih 1959)
p.beta_T   = 3.0e-4;    % thermal expansion coefficient of water at ~30 C [1/K]
p.fS_max   = 2.0;       % largest admissible channel-top salinity factor [-]
p.s_frac   = 0.8;       % design spacing = s_frac * s_max [-]
p.d_grid   = (0.6:0.1:3.0) * 1e-3; % candidate channel diameters [m]
p.g        = 9.81;

% ---------------- Capillary supply -----------------------------------------
p.sigma_w  = 0.072;     % surface tension [N m^-1]
p.theta_c  = 60;        % apparent contact angle on char-coated fibres [deg] (ASSUMPTION)
p.mu_w     = 0.8e-3;    % dynamic viscosity [Pa s]
p.k_KC     = 5;         % Kozeny constant [-]

% ---------------- Screening material/energy balance ------------------------
p.cp_gfrp  = 1000;      % laminate heat capacity [J kg^-1 K^-1] (ASSUMPTION)
p.dH_pyr   = 1.0e6;     % endothermic decomposition enthalpy [J per kg resin] (ASSUMPTION)
p.LHV_vol  = 30e6;      % lower heating value of pyrolysis oil+gas [J kg^-1] (ASSUMPTION)
p.eta_furn = 0.60;      % furnace thermal efficiency [-] (ASSUMPTION)
p.rho_core = 80;        % core foam density [kg m^-3] (ASSUMPTION)
p.PSH      = 5.0;       % peak-sun-hours per day for outdoor estimate [h d^-1] (ASSUMPTION)
p.life_yr  = 2.0;       % evaporator service life [yr] (ASSUMPTION)
p.derate   = 0.70;      % outdoor derating for wind and soiling [-] (ASSUMPTION)
p.eta_col  = 0.60;      % vapour-to-water collection efficiency of a condensing cover [-] (ASSUMPTION)
% ---------------- Buoyancy / waterline ---------------------------------------
p.rho_sw   = 1025;      % seawater density [kg m^-3]
p.rho_lam  = 1900;      % density of GFRP laminate used as ballast [kg m^-3] (ASSUMPTION)
p.uptake   = 0.05;      % long-term water uptake of core foam [volume fraction] (ASSUMPTION)
end
