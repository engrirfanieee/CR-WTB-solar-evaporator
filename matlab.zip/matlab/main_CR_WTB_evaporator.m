%% MAIN_CR_WTB_EVAPORATOR
% Reproduces every number, table entry and figure (Figs. 2-7) and Tables 4, 5, 6, 7 and 8 of the manuscript
% "Char-Retentive Partial Pyrolysis of End-of-Life Wind Turbine Blades into
%  Self-Floating Solar Interfacial Evaporators for Desalination" (revised).
%
% Run from this folder in MATLAB (R2019b or newer) or GNU Octave (7 or newer):
%   >> main_CR_WTB_evaporator
% Outputs: ../figures/Figure_2.png ... Figure_7.png (600 dpi) and results.txt
% Requires am15g.csv (ASTM G173-03 AM1.5G, 300-2500 nm) in this folder.
% No toolbox is required. Runtime: about 5-10 minutes (design optimisation and
% two Monte Carlo sets).

clear; close all; clc;
outdir = fullfile('..', 'figures');
if ~exist(outdir, 'dir'), mkdir(outdir); end
fid = fopen('results.txt', 'w');
logf = @(varargin) fprintf_both(fid, varargin{:});
if exist('rng', 'file') || exist('rng', 'builtin'), rng(42); else, rand('state', 42); end
set(0, 'defaultAxesFontSize', 8, 'defaultTextFontSize', 8, 'defaultLineLineWidth', 1.2);
P1 = [0.08 0.17 0.36 0.72];   % left panel position (normalised)
P2 = [0.57 0.17 0.30 0.72];   % right panel position (room for colorbar)
DEG = '°C';
p = params_default();
C2K = 273.15;
cols = [0.13 0.40 0.67; 0.84 0.37 0.00; 0.20 0.60 0.30; 0.55 0.55 0.55];
ttl = @(s) title(s, 'Units', 'normalized', 'Position', [0.02 1.02], 'HorizontalAlignment', 'left');

%% 1. Pyrolysis kinetics and process window  (Fig. 2, Table 4)
A_pre = p.beta_ref * p.Ea / (8.314 * p.Tpeak_ref^2) * exp(p.Ea / (8.314 * p.Tpeak_ref));
logf('Kinetics: calibrated A = %.3e 1/s (Ea = %.0f kJ/mol, Tp = %.0f C)\n', A_pre, p.Ea/1e3, p.Tpeak_ref - C2K);
betas = [5 10 20] / 60;
new_figure(); axes('Position', P1); hold on; box on;
Tp = zeros(1, numel(betas)); hA = zeros(1, numel(betas)); dmax = 0; DA = cell(1, 3);
for i = 1:numel(betas)
    pp = p; pp.beta_ramp = betas(i);
    [al, ~, TT] = pyrolysis_conversion(pp, 650 + C2K, 0);
    dadT = gradient(al, TT); dmax = max(dmax, max(dadT));
    Tp(i) = TT(find(dadT == max(dadT), 1)) - C2K;
    hA(i) = plot(TT - C2K, al, '-', 'Color', cols(i, :));
    DA{i} = {TT - C2K, dadT};
end
for i = 1:numel(betas), plot(DA{i}{1}, DA{i}{2} / dmax, '--', 'Color', cols(i, :)); end
ylabel('\alpha (solid) and normalised d\alpha/dT (dashed)'); ylim([0 1.1]);
xlabel(['Temperature (' DEG ')']); xlim([250 600]);
legend(hA, {'5 K min^{-1}', '10 K min^{-1}', '20 K min^{-1}'}, 'Location', 'east', 'Box', 'off');
ttl('(a)');
logf('Fig2a: peak conversion-rate temperatures (C) at 5/10/20 K/min: %.1f %.1f %.1f\n', Tp);
Th = (340:2:480) + C2K; th = (0:2:120) * 60;
AL = zeros(numel(th), numel(Th));
for i = 1:numel(Th), for j = 1:numel(th)
    al = pyrolysis_conversion(p, Th(i), th(j)); AL(j, i) = al(end);
end, end
axes('Position', P2); hold on; box on;
LU = log10(max(1 - AL, 1e-6));
contourf(Th - C2K, th / 60, max(LU, -4), -4:0.25:0, 'LineStyle', 'none');
contour(Th - C2K, th / 60, LU, [-2 -2], 'k-', 'LineWidth', 1.6);
plot([450 450], [0 120], 'w--', 'LineWidth', 1.4);
colormap(gca, cmap_seq()); caxis([-4 0]); cb = colorbar; ylabel(cb, 'log_{10}(1 - \alpha) at end of hold');
xlabel(['Hold temperature (' DEG ')']); ylabel('Hold time (min)');
text(447, 110, '450 °C', 'Color', 'w', 'FontSize', 7, 'HorizontalAlignment', 'right');
text(372, 40, '\alpha = 0.99', 'Color', 'w', 'FontSize', 7);
ttl('(b)');
print(gcf, fullfile(outdir, 'Figure_2.png'), '-dpng', '-r600');
for Tsel = [380 400 420 450]
    i = find(abs(Th - C2K - Tsel) < 1e-9); j = find(AL(:, i) >= p.alpha_req, 1);
    logf('Fig2b: T=%d C -> t_hold(alpha>=0.99) = %d min\n', Tsel, th(j)/60);
end
Tmin30 = window_low(p, 30*60); logf('Fig2b: minimum hold temperature for alpha>=0.99 with 30 min hold = %d C\n', Tmin30);
% Table 4: sensitivity of the window to Ea and Tp
EaV = [120 150 180] * 1e3; TpV = [370 390 410] + C2K;
logf('Table4: Ea(kJ/mol) Tp(C) | Tmin(30 min hold) | alpha at 450 C, no hold\n');
for i = 1:numel(EaV), for j = 1:numel(TpV)
    pp = p; pp.Ea = EaV(i); pp.Tpeak_ref = TpV(j);
    al = pyrolysis_conversion(pp, 450 + C2K, 0);
    logf('Table4: %3.0f %3.0f | %4d | %.4f\n', EaV(i)/1e3, TpV(j)-C2K, window_low(pp, 30*60), al(end));
end, end

%% 2. Char coating and optics  (Fig. 3)
c0 = char_coating(p, 1.0);
[A0, o0] = optics_KM(p, c0.delta, p.L_a);
pb = p; pb.spectrum = 'BB'; Abb = optics_KM(pb, c0.delta, p.L_a);
logf('Char: %.3f kg char/kg fibre; %.1f wt%% char in solid; coat thickness %.2f um\n', ...
     c0.m_char_per_fibre, 100*c0.char_wt_frac, c0.delta*1e6);
logf('Optics: beta = %.0f 1/m (1/beta = %.0f um); r_c = %.3f; R_s = %.3f\n', o0.beta, 1e6/o0.beta, o0.r_c, o0.R_s);
logf('Optics: A (AM1.5G) = %.4f; A (5778 K blackbody) = %.4f\n', A0, Abb);
Ycv = linspace(0, 0.25, 101); Lop = [0.025 0.05 0.10 2.0] * 1e-3;
Agrid = zeros(numel(Lop), numel(Ycv));
for i = 1:numel(Lop), for j = 1:numel(Ycv)
    pp = p; pp.Yc = Ycv(j); cc_ = char_coating(pp, 1.0); Agrid(i, j) = optics_KM(pp, cc_.delta, Lop(i));
end, end
new_figure(); axes('Position', P1); hold on; box on;
lc = [0.55 0.55 0.55; 0.13 0.40 0.67; 0.84 0.37 0.00; 0.20 0.60 0.30];
for i = 1:numel(Lop), plot(Ycv, Agrid(i, :), '-', 'Color', lc(i, :)); end
plot([p.Yc p.Yc], [0 1], 'k:');
xlabel('Char yield, Y_c (kg char per kg resin)'); ylabel('Solar absorptance, A (-)'); ylim([0 1]);
legend({'L_a = 0.025 mm', '0.05 mm', '0.10 mm', '2.0 mm'}, 'Location', 'southeast', 'Box', 'off', 'Color', 'none');
ttl('(a)');
for i = 1:numel(Lop)
    logf('Fig3a: A at L_a = %.3f mm and Yc = %.2f: %.3f\n', Lop(i)*1e3, p.Yc, interp1(Ycv, Agrid(i, :), p.Yc));
end
logf('Fig3a: A at L_a = 0.5 mm and Yc = %.2f: %.3f\n', p.Yc, optics_KM(p, c0.delta, 0.5e-3));
fY = @(Y) optics_KM(setfield(p, 'Yc', Y), char_coating(setfield(p, 'Yc', Y), 1.0).delta, p.L_a) - 0.90;
Ycrit = fzero(fY, [0.001 0.15]);
logf('Fig3a: minimum Yc giving A>=0.90 at L_a = 2 mm: %.4f\n', Ycrit);
axes('Position', P2); hold on; box on;
w = solar_weights(p, p.lambda);
area(p.lambda*1e6, w / max(w), 'FaceColor', [0.92 0.92 0.92], 'EdgeColor', 'none');
Ysel = [0.02 0.05 0.15]; hS = zeros(1, 3);
for i = 1:numel(Ysel)
    pp = p; pp.Yc = Ysel(i); cc_ = char_coating(pp, 1.0);
    [Ai, oi] = optics_KM(pp, cc_.delta, p.L_a);
    hS(i) = plot(oi.lambda * 1e6, oi.A_spec, '-', 'Color', lc(i + 1, :));
    logf('Fig3b: Yc=%.2f -> coat %.3f um, A = %.3f\n', Ysel(i), cc_.delta*1e6, Ai);
end
xlabel('Wavelength (\mum)'); ylabel('Spectral absorptance (-)'); ylim([0 1]); xlim([0.3 2.5]);
legend(hS, {'Y_c = 0.02', 'Y_c = 0.05', 'Y_c = 0.15'}, 'Location', 'southwest', 'Box', 'off', 'Color', 'none');
ttl('(b)');
print(gcf, fullfile(outdir, 'Figure_3.png'), '-dpng', '-r600');

%% 3. Design optimisation: baseline, nominal optimum and robust design  (Fig. 4, Table 5)
[dO, tab] = optimise_design(p);
pR = p; pR.Ra_c = 16 * p.Ra_c; [dRr, tabR] = optimise_design(pR);   % designed for Ra_c = 1088
[dCw, tabC] = optimise_combined(p);                                  % recommended: robust to the combined adverse case
dR = evaluate_design(p, dCw.d_ch, dCw.s_sp);                          % recommended geometry at baseline Ra_c
dR16 = evaluate_design(pR, dCw.d_ch, dCw.s_sp);                       % same geometry at Ra_c = 1088
[~, dWc] = spacing_combined(p, dCw.d_ch);                             % its combined adverse case
[sB, sBmax] = spacing_for_diameter(p, 2.0e-3); dB = evaluate_design(p, 2.0e-3, sB);
names_d = {'Baseline (d_ch = 2.0 mm)', 'Nominal optimum', 'Recommended design (at Ra_c = 68)', 'Recommended design (at Ra_c = 1088)', 'Recommended design (combined adverse case)', 'Design for Ra_c = 1088 only (comparison)'}; D = {dB, dO, dR, dR16, dWc, dRr};
for k = 1:numel(D)
    d = D{k}; e = d.e;
    logf(['%s: d_ch=%.2f mm, s=%.2f mm, phi=%.4f, U_core=%.2f W/m2K, A=%.3f, Ts=%.1f C, gross %.3f (eta %.1f%%), ' ...
          'dark %.3f, net %.3f kg/m2/h (eta_net %.1f%%)\n'], names_d{k}, d.d_ch*1e3, d.s_sp*1e3, d.phi, e.U_core, ...
          d.A, e.Ts - C2K, e.m_h, 100*e.eta, d.dark.m_h, d.m_net_h, 100*d.eta_net);
    logf('   energy (W/m2): evap %.0f, feed sensible %.0f, rad %.0f, conv %.0f, cond %.0f, refl %.0f; sum %.0f\n', ...
          e.q_evap, e.q_sens, e.q_rad, e.q_conv, e.q_cond, e.q_refl, e.q_evap+e.q_sens+e.q_rad+e.q_conv+e.q_cond+e.q_refl);
    logf(['   channel: L_ch=%.1f mm, v=%.2e m/s, U_mean=%.2e m/s, U_mean/v=%.2f, U_conv=%.2e m/s, xi=%.4f, dc_ex=%.3f, dc_on=%.3f wt%%, onset-limited=%d, f_S=%.3f, Nu_ch=%.4f, ' ...
          'Ra=%.0f, Ra_T=%.1f, R_rho=%.2f, t_heat=%.1f s, t_salt=%.0f s, t_transit=%.0f s, salt residual %.1e\n'], d.ch.L*1e3, d.ch.v, d.ch.U, d.ch.U_over_v, d.ch.U_conv, d.ch.xi, ...
          d.ch.dc_ex, d.ch.dc_on, d.ch.onset_limited, d.ch.f_S, d.ch.Nu, d.ch.Ra, d.ch.Ra_T, d.ch.R_rho, d.ch.t_heat, d.ch.t_salt, d.ch.t_transit, d.ch.salt_residual);
    logf('   brine: f_S at onset %.3f, overshoot chi %.3f, envelope f_S %.3f; surface: mean salinity %.2f wt%%, a_w %.4f; timescales: cycle %.1f min, absorber diffusion %.0f min, residence %.0f min\n', d.ch.f_S_on, d.ch.chi, d.ch.f_S, d.sd.c_mean, d.a_w, d.ch.T_cyc/60, d.t_abs_diff/60, d.t_abs_res/60);
    logf('   ballast: perforated plate %.1f mm (%.1f kg/m2); freeboard without ballast %.1f mm\n', d.bal.t_bal*1e3, d.bal.m_bal, d.bal.freeboard_noballast*1e3);
    logf('   salt: c_mid exact %.2f, lower %.2f, upper %.2f, strip %.2f wt%%; limit %.2f wt%%; gypsum %d; channels per m2 %.0f; capillary s_max %.2f m, theta_max %.1f deg\n', ...
          d.sd.c_mid, d.sd.c_mid_lower, d.sd.c_mid_upper, d.sd.c_mid_strip, d.sd.c_lim, d.sd.gypsum, 1/d.s_sp^2, d.cap.s_max_cap, d.cap.theta_max);
end
dRec = dR;   % recommended design: robust geometry, evaluated at the baseline Ra_c
% spacing limits from each salt criterion at the recommended design (flux, Ts and f_S fixed)
crit = {'Pe_sq', 'Pe_lower', 'Pe_upper', 'Pe_strip'}; smx = zeros(1, 4);
for k = 1:4
    g = @(sp) log(channel_model(dRec.p, dRec.e.m, dRec.d_ch, sp, dRec.e.Ts).f_S) + ...
              getfield(salt_design(p, dRec.e.m, p.L_a, dRec.d_ch, sp, 1), crit{k}) - log(dRec.sd.c_lim/p.S0);
    smx(k) = fzero(g, [1.2*dRec.d_ch 40e-3]);
end
logf('s_max at recommended design: exact %.2f, equal-area circle %.2f, circumscribed circle %.2f, strip %.2f mm\n', smx*1e3);
logf('Thermal limit at 1 sun (latent only, h_lv at 40 C): %.3f kg/m2/h\n', 3600*p.q_sun/(2.501e6-2370*40));
for i = 1:numel(tab)
    logf('Table-d: d=%.1f mm s=%.2f net=%.3f f_S=%.3f onset-limited=%d cond=%.0f feasible=%d | Ra_c=1088: s=%.2f net=%.3f f_S=%.3f feasible=%d | combined: s=%.2f net=%.3f f_S(adverse)=%.3f feasible=%d\n', ...
         tab(i).d*1e3, tab(i).s*1e3, tab(i).net, tab(i).fS, tab(i).onset, tab(i).cond, tab(i).feasible, tabR(i).s*1e3, tabR(i).net, tabR(i).fS, tabR(i).feasible, ...
         tabC(i).s*1e3, tabC(i).net, tabC(i).fSW, tabC(i).feasible);
end
new_figure();
axes('Position', [0.08 0.17 0.22 0.72]); hold on; box on;
Eb = [dB.e.q_evap dB.e.q_sens dB.e.q_rad dB.e.q_conv dB.e.q_cond dB.e.q_refl;
      dR.e.q_evap dR.e.q_sens dR.e.q_rad dR.e.q_conv dR.e.q_cond dR.e.q_refl;
      dO.e.q_evap dO.e.q_sens dO.e.q_rad dO.e.q_conv dO.e.q_cond dO.e.q_refl] / p.q_sun * 100;
hb = bar(1:3, Eb, 'stacked');
bc = [0.13 0.40 0.67; 0.55 0.75 0.90; 0.84 0.37 0.00; 0.95 0.75 0.10; 0.50 0.50 0.50; 0.80 0.80 0.80];
for k = 1:6, set(hb(k), 'FaceColor', bc(k, :), 'EdgeColor', 'none'); end
set(gca, 'XTick', 1:3, 'XTickLabel', {'2.0', sprintf('%.1f', dR.d_ch*1e3), sprintf('%.1f', dO.d_ch*1e3)}); xlim([0.4 3.6]);
xlabel('Channel diameter, d_{ch} (mm)'); ylabel('Share of incident solar flux (%)'); ylim([0 100]);
lg = legend({'Evaporation', 'Feed heating', 'Radiation', 'Convection', 'Conduction', 'Reflection'}, 'Box', 'off');
set(lg, 'Position', [0.31 0.42 0.12 0.34]);
ttl('(a)');
axes('Position', P2 + [0 0 0.08 0]); hold on; box on;
Lcv = (5:2.5:40) * 1e-3; dchv = [dRec.d_ch 2.0e-3 dO.d_ch];
for i = 1:numel(dchv)
    mn = zeros(size(Lcv));
    for j = 1:numel(Lcv)
        pp = p; pp.L_core = Lcv(j); sj = spacing_for_diameter(pp, dchv(i)); dd = evaluate_design(pp, dchv(i), sj); mn(j) = dd.m_net_h;
    end
    plot(Lcv * 1e3, mn, '-o', 'Color', lc(i + 1, :), 'MarkerSize', 3, 'MarkerFaceColor', lc(i + 1, :));
    logf('Fig4b: d_ch=%.1f mm: net rate at L_core 5/10/20/40 mm = %.3f / %.3f / %.3f / %.3f kg/m2/h\n', ...
         dchv(i)*1e3, mn(1), mn(abs(Lcv-10e-3)<1e-9), mn(abs(Lcv-20e-3)<1e-9), mn(end));
end
xlabel('Core thickness, L_{core} (mm)'); ylabel('Net evaporation rate (kg m^{-2} h^{-1})');
set(gca, 'XTick', [5 10 20 30 40]); xlim([5 40]); ylim([0.5 0.95]);
legend({sprintf('d_{ch} = %.1f mm (recommended)', dRec.d_ch*1e3), '2.0 mm', sprintf('%.1f mm (nominal optimum)', dO.d_ch*1e3)}, 'Location', 'southeast', 'Box', 'off');
ttl('(b)');
print(gcf, fullfile(outdir, 'Figure_4.png'), '-dpng', '-r600');

%% 4. Salt rejection: exact cell, bounds and strip; diameter trade-off  (Fig. 5)
new_figure(); axes('Position', P1); hold on; box on;
sv = linspace(1.5e-3, 12e-3, 160); Cx = zeros(4, numel(sv));
for k = 1:numel(sv)
    chk = channel_model(dRec.p, dRec.e.m, dRec.d_ch, sv(k), dRec.e.Ts);
    sdk = salt_design(p, dRec.e.m, p.L_a, dRec.d_ch, sv(k), chk.f_S);
    Cx(:, k) = [sdk.c_mid; sdk.c_mid_lower; sdk.c_mid_upper; sdk.c_mid_strip] / p.S0;
end
plot(sv*1e3, Cx(1, :), '-', 'Color', cols(1, :), 'LineWidth', 1.6);
plot(sv*1e3, Cx(2, :), ':', 'Color', cols(1, :)); plot(sv*1e3, Cx(3, :), '--', 'Color', cols(1, :));
plot(sv*1e3, Cx(4, :), '-.', 'Color', cols(2, :));
plot(sv*1e3, p.S_sat/p.S0*ones(size(sv)), 'k--'); plot(sv*1e3, dRec.sd.c_lim/p.S0*ones(size(sv)), 'k:');
plot([dRec.s_sp dRec.s_sp]*1e3, [1 20], 'Color', [0.5 0.5 0.5]);
set(gca, 'YScale', 'log'); ylim([1 40]); xlim([1.5 12]);
xlabel('Channel spacing, s (mm)'); ylabel('Peak absorber salinity, c_{mid}/c_0 (-)');
legend({'square cell (exact)', 'equal-area circle', 'circumscribed circle', '1-D strip', 'NaCl saturation', 'gypsum onset (limit)', 'design spacing'}, ...
       'Location', 'northwest', 'Box', 'on', 'Color', 'w', 'FontSize', 6.5);
ttl('(a)');
axes('Position', P2 + [0 0 0.08 0]); hold on; box on;
dv = [tab.d]*1e3; nv = [tab.net]; fe = [tab.feasible]; nvR = [tabR.net]; feR = [tabR.feasible];
h1 = plot(dv, nv, '-', 'Color', cols(1, :)); h2 = plot(dv(feR), nvR(feR), '-', 'Color', cols(3, :));
h3 = plot(dv(~feR & ~isnan(nvR)), nvR(~feR & ~isnan(nvR)), 'o', 'Color', cols(3, :), 'MarkerSize', 3);
h4 = plot(dO.d_ch*1e3, dO.m_net_h, 'kp', 'MarkerSize', 8, 'MarkerFaceColor', 'k');
nvC = [tabC.net]; feC = [tabC.feasible];
h6 = plot(dv(feC), nvC(feC), '-', 'Color', cols(2, :), 'LineWidth', 1.4);
h5 = plot(dR.d_ch*1e3, dR.m_net_h, 'kd', 'MarkerSize', 6, 'MarkerFaceColor', [0.6 0.6 0.6]);
xlabel('Channel diameter, d_{ch} (mm)'); ylabel('Net evaporation rate (kg m^{-2} h^{-1})');
legend([h1 h2 h6 h3 h4 h5], {'designed for Ra_c = 68', 'designed for Ra_c = 1088', 'designed for combined adverse case', 'infeasible (f_S > 2)', 'nominal optimum', 'recommended'}, 'Location', 'southeast', 'Box', 'off', 'FontSize', 6.5);
ylim([0.70 0.88]);
ttl('(b)');
print(gcf, fullfile(outdir, 'Figure_5.png'), '-dpng', '-r600');

%% 5. Monte Carlo of the fixed geometries  (Fig. 6)
N = 1000;  % see results.txt and Section 4.6 for the 5000-sample convergence check
modes = {'wide', 'relative'}; RHO = cell(1, 2);
for mm = 1:2
    [nm, lo, hi] = mc_ranges(modes{mm});
    X = lo + (hi - lo) .* rand(N, numel(lo));
    Y = zeros(N, 1); G = Y; Aout = Y; DRY = false(N, 1); CRY = DRY; ONS = DRY; GYP = DRY; CM = Y; FS = Y;
    for n = 1:N
        pp = p; for k = 1:numel(nm), pp.(nm{k}) = X(n, k); end
        dd = evaluate_design(pp, dRec.d_ch, dRec.s_sp);
        Y(n) = dd.m_net_h; G(n) = dd.e.m_h; Aout(n) = dd.A; DRY(n) = dd.dry; CRY(n) = dd.sd.crystallises;
        ONS(n) = dd.ch.onset_limited; CM(n) = dd.sd.c_mid; FS(n) = dd.ch.f_S; GYP(n) = dd.sd.gypsum;
    end
    wet = ~DRY; ok = wet & ~CRY; Yk = sort(Y(ok)); Nk = numel(Yk); q = @(f) Yk(max(1, round(f * Nk)));
    logf('MC-%s (N=%d): dry-out %.1f%%; of wetted samples: NaCl crystallisation %.1f%%, gypsum onset exceeded %.1f%%, onset-limited channels %.1f%%\n', modes{mm}, N, ...
         100*mean(DRY), 100*sum(CRY & wet)/sum(wet), 100*sum(GYP & wet)/sum(wet), 100*sum(ONS & wet)/sum(wet));
    logf('MC-%s: net rate (wetted, non-crystallising) median %.3f, P5 %.3f, P95 %.3f kg/m2/h; mean %.3f, sd %.3f\n', modes{mm}, q(0.5), q(0.05), q(0.95), mean(Yk), std(Yk));
    logf('MC-%s: wetted samples: f_S P50 %.3f, P95 %.3f; peak salinity P50 %.1f, P95 %.1f wt%%; absorptance P5 %.3f\n', modes{mm}, ...
         prctile_local(FS(wet), 0.5), prctile_local(FS(wet), 0.95), prctile_local(CM(wet), 0.5), prctile_local(CM(wet), 0.95), prctile_local(Aout, 0.05));
    RHO{mm} = rank_corr(X(wet, :), Y(wet)); rg = rank_corr(X(wet, :), G(wet));
    for k = 1:numel(nm), logf('   %s: rho_net(%s) = %+.3f, rho_gross = %+.3f\n', modes{mm}, nm{k}, RHO{mm}(k), rg(k)); end
    if mm == 1, Ywide = Yk; qw = [q(0.05) q(0.5) q(0.95)]; Xw = X; end
end
[nm, lo, hi] = mc_ranges('wide'); Yr = zeros(N, 1); okr = false(N, 1); wr = okr; gr = okr;
for n = 1:N
    pp = p; for k = 1:numel(nm), pp.(nm{k}) = Xw(n, k); end
    dd = evaluate_design(pp, dO.d_ch, dO.s_sp); Yr(n) = dd.m_net_h; okr(n) = dd.operable; wr(n) = ~dd.dry; gr(n) = dd.sd.gypsum;
end
Yrs = sort(Yr(okr)); Nr = numel(Yrs);
logf('MC-wide nominal optimum (comparison): NaCl crystallisation in %.1f%% and gypsum onset in %.1f%% of wetted samples; net median %.3f, P5 %.3f, P95 %.3f kg/m2/h\n', ...
     100*sum(wr & ~okr)/sum(wr), 100*sum(wr & gr)/sum(wr), Yrs(round(0.5*Nr)), Yrs(round(0.05*Nr)), Yrs(round(0.95*Nr)));
new_figure(); axes('Position', P1); hold on; box on;
edges = linspace(min(Ywide), max(Ywide), 31); ctr = 0.5 * (edges(1:end-1) + edges(2:end)); cnt = zeros(size(ctr));
for k = 1:numel(ctr), cnt(k) = sum(Ywide >= edges(k) & (Ywide < edges(k+1) | (k == numel(ctr) & Ywide <= edges(k+1)))); end
bar(ctr, cnt / numel(Ywide) * 100, 1, 'FaceColor', [0.13 0.40 0.67], 'EdgeColor', 'w');
yl = ylim; plot([qw(2) qw(2)], yl, 'k-'); plot([qw(1) qw(1)], yl, 'k:'); plot([qw(3) qw(3)], yl, 'k:');
xlabel('Net evaporation rate (kg m^{-2} h^{-1})'); ylabel('Frequency (%)');
ttl('(a)');
axes('Position', [0.60 0.17 0.36 0.72]); hold on; box on;
lbl = {'Y_c', 'k_c', '\epsilon_a', 'h_c', 'k_{foam}', 'C_{ex}', 'd_f', '\theta_c', 'L_{core}', 'RH', 'w_f', 'Ra_c'};
[~, ord] = sort(abs(RHO{1}), 'ascend');
bh = barh(1:numel(ord), [RHO{1}(ord)' RHO{2}(ord)'], 1);
set(bh(1), 'FaceColor', [0.84 0.37 0.00], 'EdgeColor', 'none'); set(bh(2), 'FaceColor', [0.13 0.40 0.67], 'EdgeColor', 'none');
set(gca, 'YTick', 1:numel(ord), 'YTickLabel', lbl(ord)); xlim([-1 1]); ylim([0.4 numel(ord)+0.6]);
xlabel('Spearman rank correlation with net rate (-)');
legend({'Wide ranges', '\pm25% ranges'}, 'Location', 'southwest', 'Box', 'off');
ttl('(b)');
print(gcf, fullfile(outdir, 'Figure_6.png'), '-dpng', '-r600');

%% 6. Benchmark against a published floating evaporator (Ni et al., 2018)  (Table 7)
pb = p; pb.a_w = 1.0; pb.q_cond_fixed = 110; pb.c_pw = 0;   % fresh water; reported conduction loss; no piped feed
hcv = [5 8 15];
for k = 1:numel(hcv)
    pb.h_c = hcv(k); e1 = evaporator_energy(pb, 0.85, 0, [], 1); e0 = evaporator_energy(setfield(pb, 'q_cond_fixed', 0), 0.85, 0, 0, 1);
    logf('Benchmark h_c=%2d: Ts %.1f C, eta_net %.1f%% (gross %.1f%%), radiation %.1f%%, convection %.1f%%, conduction %.1f%%\n', hcv(k), ...
         e1.Ts - C2K, 100*(e1.m - e0.m)*(2.501e6-2370*(e1.Ts-C2K))/1000, 100*e1.eta, e1.q_rad/10, e1.q_conv/10, e1.q_cond/10);
end
logf('Benchmark reported (Ni et al. 2018): vapour at 42 C, efficiency 57 +/- 2.5%%, radiation 11%%, convection 9%%, conduction 11%%, reflection 15%%\n');

%% 7. Absorptance sensitivity and buoyancy  (Fig. 7)
Av = 0.80:0.01:0.99; mA = zeros(size(Av));
for i = 1:numel(Av)
    pA = dRec.p; pA.a_w = dRec.a_w;   % water activity of the operating state
    e1 = evaporator_energy(pA, Av(i), dRec.phi, [], dRec.ch.Nu); e0 = evaporator_energy(dRec.p, Av(i), dRec.phi, 0, 1); mA(i) = e1.m_h - e0.m_h;
end
logf('Fig7a: net rate at A = 0.80/0.90/0.95/0.99: %.3f / %.3f / %.3f / %.3f kg/m2/h; slope %.3f per 0.01 A\n', ...
     mA(1), mA(abs(Av-0.90)<1e-9), mA(abs(Av-0.95)<1e-9), mA(end), (mA(end)-mA(1))/(numel(Av)-1));
new_figure(); axes('Position', P1); hold on; box on;
plot(Av, mA, '-', 'Color', cols(1, :)); plot([dRec.A dRec.A], [0.6 1.0], 'k:');
xlabel('Solar absorptance, A (-)'); ylabel('Net evaporation rate (kg m^{-2} h^{-1})'); ylim([0.6 1.0]);
text(dRec.A - 0.003, 0.63, 'predicted char mat', 'HorizontalAlignment', 'right', 'FontSize', 7);
ttl('(a)');
axes('Position', P2 + [0 0 0.06 0]); hold on; box on;
Lcb = (5:2.5:40) * 1e-3; FB = zeros(size(Lcb)); MB = FB;
for j = 1:numel(Lcb)
    pp = p; pp.L_core = Lcb(j); dd = evaluate_design(pp, dRec.d_ch, dRec.s_sp); bb = screening_balance(pp, dd);
    FB(j) = bb.freeboard_noballast * 1e3; MB(j) = bb.t_ballast * 1e3;
end
plot(Lcb*1e3, FB, '-o', 'Color', cols(2, :), 'MarkerSize', 3, 'MarkerFaceColor', cols(2, :));
plot(Lcb*1e3, MB, '-s', 'Color', cols(3, :), 'MarkerSize', 3, 'MarkerFaceColor', cols(3, :));
xlabel('Core thickness, L_{core} (mm)'); ylabel('Length (mm)'); xlim([5 40]); ylim([0 50]); set(gca, 'XTick', [5 10 20 30 40]);
legend({'Freeboard without ballast', 'Perforated laminate ballast for zero freeboard'}, 'Location', 'northwest', 'Box', 'off');
ttl('(b)');
print(gcf, fullfile(outdir, 'Figure_7.png'), '-dpng', '-r600');
logf('Fig7b: L_core 10/20 mm: freeboard without ballast %.1f / %.1f mm; ballast thickness %.1f / %.1f mm\n', ...
     FB(abs(Lcb-10e-3)<1e-9), FB(abs(Lcb-20e-3)<1e-9), MB(abs(Lcb-10e-3)<1e-9), MB(abs(Lcb-20e-3)<1e-9));

%% 8. Screening energy, water and buoyancy balance  (Table 5)
pOut = p; pOut.h_c = p.h_c_out; dOut = evaluate_design(pOut, dRec.d_ch, dRec.s_sp);
logf('Outdoor (h_c = %d): Ts %.1f C, gross %.3f, net %.3f kg/m2/h, c_mid %.2f wt%%, crystallises %d\n', p.h_c_out, dOut.e.Ts - C2K, dOut.e.m_h, dOut.m_net_h, dOut.sd.c_mid, dOut.sd.crystallises);
b = screening_balance(p, dOut); bL = screening_balance(p, dRec);
logf('Screening: furnace %.2f MJ/kg; volatiles %.2f MJ/kg; Phi %.1f (bounds %.1f-%.1f)\n', b.Q_in_MJ, b.Q_vol_MJ, b.self_suff, b.self_suff_low, b.self_suff_high);
logf('Screening: absorber %.3f kg/m2 (from %.3f kg laminate/m2); core %.3f kg/m2\n', b.m_absorber, b.m_lam_per_m2, b.m_core);
logf('Screening (lab h_c, for comparison): vapour %.0f kg/m2/yr\n', bL.vapour_yr);
logf('Screening: vapour %.0f kg/m2/yr (range %.0f-%.0f); water (eta_col %.2f) %.0f kg/m2/yr (range %.0f-%.0f)\n', ...
     b.vapour_yr, b.vapour_yr_range, p.eta_col, b.water_yr, b.water_yr_range);
logf('Material: pyrolysed laminate %.3f, core %.3f, ballast %.2f, total blade-derived %.2f kg/m2; water over %.0f yr: %.0f kg per kg total, %.0f kg per kg pyrolysed laminate\n', ...
     b.m_lam_per_m2, b.m_core, b.m_ballast, b.m_blade_total, p.life_yr, b.water_life_per_kg_total, b.water_life_per_kg_processed);
logf('Buoyancy: freeboard without ballast %.1f mm; ballast %.1f kg/m2 (%.1f mm perforated laminate); extra draft %.2f mm per 1 vol%% uptake\n', ...
     b.freeboard_noballast*1e3, b.m_ballast, b.t_ballast*1e3, b.sink_per_pct_uptake*1e3);
% thinner core variant (spacing re-derived for Ra_c = 1088 at the same diameter)
p10 = p; p10.L_core = 10e-3; p10R = p10; p10R.Ra_c = 16 * p.Ra_c; s10 = spacing_combined(p10, dRec.d_ch);
d10 = evaluate_design(p10, dRec.d_ch, s10); d10R = evaluate_design(p10R, dRec.d_ch, s10);
p10o = p10; p10o.h_c = p.h_c_out; d10o = evaluate_design(p10o, dRec.d_ch, s10); b10 = screening_balance(p10, d10o);
logf('Variant L_core = 10 mm: s %.2f mm, net %.3f (Ra_c 68) / %.3f (Ra_c 1088) kg/m2/h, c_mid %.2f / %.2f wt%%, ballast %.1f mm (%.1f kg/m2), total blade-derived %.2f kg/m2, water %.0f kg/m2/yr, %.0f kg per kg total over %.0f yr\n', ...
     s10*1e3, d10.m_net_h, d10R.m_net_h, d10.sd.c_mid, d10R.sd.c_mid, b10.t_ballast*1e3, b10.m_ballast, b10.m_blade_total, b10.water_yr, b10.water_life_per_kg_total, p.life_yr);

%% 9. Verification of the numerical solution and model-form scenarios  (Tables 6 and 8)
D2 = {dRec, dR16};
for k = 1:2
    d = D2{k}; e = d.e;
    rTop = (d.A*p.q_sun - (e.q_evap + e.q_sens + e.q_rad + e.q_conv + e.q_cond)) / p.q_sun;
    rTot = (p.q_sun - (e.q_evap + e.q_sens + e.q_rad + e.q_conv + e.q_cond + e.q_refl)) / p.q_sun;
    rW = (1000 * d.ch.v * pi * (d.d_ch/2)^2 / d.s_sp^2 - e.m) / e.m;
    dA = evaluate_design(d.p, d.d_ch, d.s_sp, 5);
    logf('Verification (Ra_c=%d): energy residual top %.1e, total %.1e; water balance %.1e; channel salt balance %.1e; fixed point %d iterations, |dNu| %.1e, |da_w| %.1e; start Nu=5: dTs %.1e K, dnet %.1e kg/m2/h\n', ...
         d.p.Ra_c, rTop, rTot, rW, d.ch.salt_residual, d.iter, d.dNu, d.daw, abs(dA.e.Ts - e.Ts), abs(dA.m_net_h - d.m_net_h));
end
for nn = [40 80 160]
    vv = verify_absorber_pde(dRec.sd.Pe_sq, dRec.d_ch / dRec.s_sp, nn);
    logf('Verification absorber PDE (n=%d): ln(c_corner) numerical %.5f vs exact %.5f, rel. error %.1e, max field error %.1e\n', nn, vv.lnc_num, vv.lnc_exact, vv.rel_err, vv.max_field_err);
end
% model-form scenarios for the recommended design, each at Ra_c = 68 and 1088,
% singly and combined (Table 8)
scn = {'Reference', {}, 1, 0; ...
       'Circumscribed-circle absorber model', {}, 1, 1; ...
       '25% of channels blocked (uniform)', {}, sqrt(1/0.75), 0; ...
       'Denser, more tortuous absorber (eps 0.6, tau 2.0)', {'eps_a', 0.6, 'tau', 2.0}, 1, 0; ...
       'Exchange flow 10x weaker than sampled (C_ex = 3000)', {'C_ex', 3000}, 1, 0; ...
       'Combined: dense absorber + 25% blocked + C_ex = 3000', {'eps_a', 0.6, 'tau', 2.0, 'C_ex', 3000}, sqrt(1/0.75), 0; ...
       'Combined, with circumscribed-circle model', {'eps_a', 0.6, 'tau', 2.0, 'C_ex', 3000}, sqrt(1/0.75), 1};
for k = 1:size(scn, 1)
    out = zeros(2, 3);
    for m = 1:2
        pp = p; if m == 2, pp.Ra_c = 16 * p.Ra_c; end
        kv = scn{k, 2}; for q = 1:2:numel(kv), pp.(kv{q}) = kv{q+1}; end
        dd = evaluate_design(pp, dRec.d_ch, dRec.s_sp * scn{k, 3});
        cm = dd.sd.c_mid; if scn{k, 4}, cm = dd.sd.c_mid_upper; end
        out(m, :) = [cm, dd.ch.f_S, dd.m_net_h];
    end
    logf('Scenario: %s: c_mid %.2f / %.2f wt%% (Ra_c 68 / 1088; gypsum %d/%d, NaCl %d/%d), f_S %.3f / %.3f, net %.3f / %.3f kg/m2/h\n', scn{k, 1}, ...
         out(:, 1), out(:, 1) >= p.CF_gyp*p.S0, out(:, 1) >= p.S_sat, out(:, 2), out(:, 3));
end
bW = p.adv.block; [~, dRrW] = deal([], evaluate_design(adverse_params(p), dRr.d_ch, dRr.s_sp / sqrt(1 - bW)));
logf('Scenario: design for Ra_c = 1088 only (d %.1f mm, s %.2f mm) under the combined adverse case: c_mid %.2f wt%%, f_S %.3f\n', dRr.d_ch*1e3, dRr.s_sp*1e3, dRrW.sd.c_mid, dRrW.ch.f_S);
logf('Recommended design: combined adverse case at its spacing: c_mid %.2f wt%%, f_S %.3f, xi %.4f; net rate cost relative to the Ra_c = 1088-only design %.1f%%\n', dWc.sd.c_mid, dWc.ch.f_S, dWc.ch.xi, 100*(dR.m_net_h/evaluate_design(p, dRr.d_ch, dRr.s_sp).m_net_h - 1));
% fixed water activity (as in earlier versions) for comparison
pF = p; pF.aw_mode = 0; pFR = pR; pFR.aw_mode = 0;
dF = evaluate_design(pF, dRec.d_ch, dRec.s_sp); dFR = evaluate_design(pFR, dRec.d_ch, dRec.s_sp);
dFO = evaluate_design(pF, dO.d_ch, dO.s_sp); dFB = evaluate_design(pF, 2.0e-3, dB.s_sp);
logf('Water activity: recommended a_w %.4f / %.4f (Ra_c 68 / 1088), mean surface salinity %.2f / %.2f wt%%; with fixed a_w = %.2f net %.3f / %.3f instead of %.3f / %.3f kg/m2/h\n', ...
     dRec.a_w, dR16.a_w, dRec.sd.c_mean, dR16.sd.c_mean, p.a_w, dF.m_net_h, dFR.m_net_h, dRec.m_net_h, dR16.m_net_h);
logf('Water activity: nominal optimum net %.3f (fixed a_w %.3f); baseline 2.0 mm net %.3f (fixed a_w %.3f) kg/m2/h\n', dO.m_net_h, dFO.m_net_h, dB.m_net_h, dFB.m_net_h);
% time scales of the intermittent regime and of the absorber (Section 4.5)
for d = {dRec, dR16, dO}
    dd = d{1};
    logf('Timescales (d_ch %.1f mm, Ra_c %d): burst transit %.0f s, cycle %.1f min, xi %.4f, overshoot chi %.3f (f_S %.3f without, %.3f with); absorber diffusion %.0f min, residence %.0f min\n', ...
         dd.d_ch*1e3, dd.p.Ra_c, dd.ch.t_transit, dd.ch.T_cyc/60, dd.ch.xi, dd.ch.chi, dd.ch.f_S_on, dd.ch.f_S, dd.t_abs_diff/60, dd.t_abs_res/60);
end
fR = @(Rc, lim) evaluate_design(setfield(p, 'Ra_c', Rc), dRec.d_ch, dRec.s_sp).sd.c_mid - lim;
Rc_g = NaN; Rc_n = NaN;
try, Rc_g = exp(fzero(@(x) fR(exp(x), p.CF_gyp*p.S0), log([p.Ra_c 1e7]))); catch, end
try, Rc_n = exp(fzero(@(x) fR(exp(x), p.S_sat), log([p.Ra_c 1e8]))); catch, end
logf('Scenario: Ra_c at which the recommended design reaches gypsum onset %.0f (%.0fx baseline) and NaCl saturation %.0f (%.0fx baseline)\n', Rc_g, Rc_g/p.Ra_c, Rc_n, Rc_n/p.Ra_c);
logf('Scenario: brine return by diffusion only: channel Peclet number v*L/D = %.0f (no steady solution below saturation)\n', dRec.ch.v * dRec.ch.L / p.D_salt);
fclose(fid);
disp('Done. See results.txt and ../figures/.');
