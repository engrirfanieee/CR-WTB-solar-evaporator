function b = screening_balance(p, d)
%SCREENING_BALANCE  Screening energy balance of char-retentive pyrolysis,
%water yield per kg of blade material, and buoyancy/waterline of the float.
w_r = 1 - p.w_f;
phi_fun = @(LHV, dH, eta) (w_r * (1 - p.Yc) * LHV) / ...
          ((p.cp_gfrp * (p.T_max_fibre - 298.15) + w_r * dH) / eta);
b.Q_in_MJ  = (p.cp_gfrp * (p.T_max_fibre - 298.15) + w_r * p.dH_pyr) / p.eta_furn / 1e6;
b.Q_vol_MJ = d.c.volatiles_per_kg * p.LHV_vol / 1e6;
b.self_suff = phi_fun(p.LHV_vol, p.dH_pyr, p.eta_furn);
b.self_suff_low  = phi_fun(20e6, 2.0e6, 0.40);   % pessimistic bound
b.self_suff_high = phi_fun(35e6, 0.5e6, 0.80);   % optimistic bound
% areal masses (kg m^-2)
b.m_absorber = d.bal.m_abs_dry;                             % char-coated fibre mat, dry
b.m_core = d.bal.m_core;                                    % reused foam core
lam_per_m2 = b.m_absorber / (p.w_f + w_r*p.Yc);             % laminate pyrolysed for the absorber
b.m_lam_per_m2 = lam_per_m2;
b.m_ballast = d.bal.m_bal;                                  % perforated laminate ballast plate
b.t_ballast = d.bal.t_bal;
b.m_blade_total = lam_per_m2 + b.m_core + b.m_ballast;       % all blade-derived material
% vapour (gross rate during operation) and collected water (illustrative scenario)
b.vapour_yr = d.e.m_h * p.PSH * 365 * p.derate;             % kg m^-2 yr^-1
b.vapour_yr_range = d.e.m_h * p.PSH * 365 * [0.5 0.9];
b.water_yr  = b.vapour_yr * p.eta_col;                       % kg m^-2 yr^-1
b.water_yr_range = b.vapour_yr_range .* [0.4 0.9];
b.water_life_per_kg_total = b.water_yr * p.life_yr / b.m_blade_total;    % incl. ballast
b.water_life_per_kg_processed = b.water_yr * p.life_yr / lam_per_m2;    % per kg pyrolysed laminate
% buoyancy
b.freeboard_noballast = d.bal.freeboard_noballast;
b.sink_per_pct_uptake = 0.01 * 1000 / p.rho_sw * p.L_core;    % extra draft per 1 vol% water uptake [m]
end
