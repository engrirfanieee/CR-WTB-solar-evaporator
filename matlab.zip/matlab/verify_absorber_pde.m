function v = verify_absorber_pde(Pe, rho0, n)
%VERIFY_ABSORBER_PDE  Independent numerical check of the exact absorber
%solution (Eq. 14). On the unit quarter cell (channel quarter-disc of radius
%rho0 = 2*r0/s at the origin, symmetry edges elsewhere) it solves
%   (i)  lap(w) = 1, w = 0 on the channel                  (scaled potential)
%   (ii) div(-G*grad(w)*c - grad(c)) = 0, c = 1 on the channel
% with second-order central differences (advective flux with the arithmetic
% mean of c at each face) and compares the corner value with the exact
% c = exp(-G*w), where G is chosen so that G*F = Pe (the Peclet number of the
% design). Returns the relative difference of ln(c_corner).
h = 1 / n; [X, Y] = meshgrid(0:h:1, 0:h:1); X = X'; Y = Y';
N = (n + 1)^2; id = reshape(1:N, n + 1, n + 1);
dir = (X.^2 + Y.^2) <= rho0^2;
nbr = @(i, j) [max(i-1, 1) + (i == 1) * 1, j; min(i+1, n+1) - (i == n+1) * 1, j; i, max(j-1, 1) + (j == 1) * 1; i, min(j+1, n+1) - (j == n+1) * 1];
% (i) potential
[I, J, V, b] = deal(zeros(5*N, 1), zeros(5*N, 1), zeros(5*N, 1), ones(N, 1) * h^2); c = 0;
for i = 1:n+1, for j = 1:n+1
    p = id(i, j);
    if dir(i, j), c = c + 1; I(c) = p; J(c) = p; V(c) = 1; b(p) = 0; continue, end
    nb = nbr(i, j); c = c + 1; I(c) = p; J(c) = p; V(c) = -4;
    for q = 1:4, c = c + 1; I(c) = p; J(c) = id(nb(q, 1), nb(q, 2)); V(c) = 1; end
end, end
w = sparse(I(1:c), J(1:c), V(1:c), N, N) \ b;
F = -w(id(n+1, n+1)); G = Pe / F;
% (ii) salt: sum over faces of [ (c_N - c_P) + G*(w_N - w_P)*(c_N + c_P)/2 ] = 0
[I, J, V] = deal(zeros(9*N, 1)); b = zeros(N, 1); c = 0;
for i = 1:n+1, for j = 1:n+1
    p = id(i, j);
    if dir(i, j), c = c + 1; I(c) = p; J(c) = p; V(c) = 1; b(p) = 1; continue, end
    nb = nbr(i, j);
    for q = 1:4
        k = id(nb(q, 1), nb(q, 2)); dw = G * (w(k) - w(p));
        c = c + 1; I(c) = p; J(c) = k; V(c) = 1 + dw / 2;
        c = c + 1; I(c) = p; J(c) = p; V(c) = -1 + dw / 2;
    end
end, end
cs = sparse(I(1:c), J(1:c), V(1:c), N, N) \ b;
v.F = F; v.G = G;
v.lnc_num = log(cs(id(n+1, n+1)));
v.lnc_exact = Pe;
v.rel_err = (v.lnc_num - v.lnc_exact) / v.lnc_exact;
v.max_field_err = max(abs(log(cs(~dir(:))) + G * w(~dir(:)))) / Pe;   % whole-field check
end
