function c = cmap_seq(n)
%CMAP_SEQ  Perceptually ordered blue-to-yellow colormap (identical in MATLAB and Octave).
if nargin < 1, n = 256; end
k = [0.27 0.00 0.33; 0.23 0.32 0.55; 0.13 0.57 0.55; 0.37 0.79 0.38; 0.99 0.91 0.14];
x = linspace(0, 1, size(k, 1)); xi = linspace(0, 1, n)';
c = [interp1(x, k(:,1), xi), interp1(x, k(:,2), xi), interp1(x, k(:,3), xi)];
end
