function c = char_coating(p, alpha)
%CHAR_COATING  Char loading and coating thickness on recovered glass fibres.
%   Resin decomposes as R -> Yc*Char + (1-Yc)*Volatiles. With conversion
%   alpha, remaining solids per kg laminate are fibre w_f, char (1-w_f)*Yc*alpha,
%   unconverted resin (1-w_f)*(1-alpha). Char is assumed to form a uniform
%   annular coat on each filament.
if nargin < 2, alpha = 1; end
w_r = 1 - p.w_f;
c.m_char_per_fibre = w_r * p.Yc * alpha / p.w_f;          % kg char / kg fibre
c.char_wt_frac     = w_r * p.Yc * alpha / (p.w_f + w_r * p.Yc * alpha + w_r * (1 - alpha));
c.resin_residual   = w_r * (1 - alpha) / (p.w_f + w_r * p.Yc * alpha + w_r * (1 - alpha));
c.delta = 0.5 * p.d_f * (sqrt(1 + c.m_char_per_fibre * p.rho_f / p.rho_c) - 1); % coat thickness [m]
c.d_coated = p.d_f + 2 * c.delta;
c.volatiles_per_kg = w_r * (1 - p.Yc) * alpha;            % kg volatiles / kg laminate
end
