function c = capillary_check(p, delta, m_flux, s_sp, L_a)
%CAPILLARY_CHECK  Darcy-Laplace lateral supply capacity of the absorber.
%   Kozeny-Carman permeability of the fibre mat and Laplace pressure from the
%   hydraulic radius. A contact angle of 90 deg or more gives no capillary
%   driving pressure, i.e. the absorber dries out (c.ok = false).
d = p.d_f + 2*delta; e = p.eps_a;
c.K = d^2 * e^3 / (16 * p.k_KC * (1 - e)^2);
r_h = d * e / (4 * (1 - e));
c.dP = 2 * p.sigma_w * cosd(p.theta_c) / (2 * r_h);
if c.dP > 0
    c.s_max_cap = sqrt(4 * 1000 * c.K * c.dP * L_a / (p.mu_w * m_flux));
else
    c.s_max_cap = 0;
end
c.ok = s_sp <= c.s_max_cap;
% largest contact angle for which capillarity can still feed spacing s_sp
cos_min = s_sp^2 * p.mu_w * m_flux / (4 * 1000 * c.K * L_a * 2 * p.sigma_w / (2 * r_h));
c.theta_max = acosd(min(cos_min, 1));
end
