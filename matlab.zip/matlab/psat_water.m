function ps = psat_water(T)
%PSAT_WATER  Saturation vapour pressure of water [Pa], Buck-type correlation, T in K.
Tc = T - 273.15;
ps = 611.21 * exp((18.678 - Tc/234.5) .* (Tc ./ (257.14 + Tc)));
end
