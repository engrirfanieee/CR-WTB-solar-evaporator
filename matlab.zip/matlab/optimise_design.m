function [best, tab] = optimise_design(p)
%OPTIMISE_DESIGN  Grid search over channel diameter. For each diameter the
%spacing follows from the exact square-cell salt criterion; the design with the
%highest net evaporation rate that satisfies all constraints (wetted absorber,
%peak salinity <= min(psi*c_sat, gypsum onset), channel-top salinity factor f_S <= fS_max) wins.
n = numel(p.d_grid);
tab = struct('d', num2cell(p.d_grid), 's', NaN, 'net', NaN, 'Ra', NaN, 'fS', NaN, 'feasible', false, 'cond', NaN, 'onset', false);
best = []; bestnet = -Inf;
for i = 1:n
    [s, ~, ok] = spacing_for_diameter(p, p.d_grid(i));
    if ~ok, continue; end
    d = evaluate_design(p, p.d_grid(i), s);
    tab(i).s = s; tab(i).net = d.m_net_h; tab(i).Ra = d.ch.Ra; tab(i).fS = d.ch.f_S;
    tab(i).feasible = d.feasible; tab(i).cond = d.e.q_cond; tab(i).onset = d.ch.onset_limited;
    if d.feasible && d.m_net_h > bestnet, best = d; bestnet = d.m_net_h; end
end
end
