function fprintf_both(fid, varargin)
%FPRINTF_BOTH  Print to the command window and to an open file.
fprintf(varargin{:}); fprintf(fid, varargin{:});
end
