function [names, lo, hi, base] = mc_ranges(mode)
%MC_RANGES  Uniform ranges of uncertain inputs for the Monte Carlo analysis.
%   mode = 'wide'     : literature/engineering ranges (Table 3); Ra_c up to 16x68
%                       covers a radius- or diameter-based Rayleigh definition
%   mode = 'relative' : every input +/-25 % around its baseline, so that the
%                       ranking is not driven by unequal range widths
if nargin < 1, mode = 'wide'; end
names = {'Yc','k_c','eps_a','h_c','k_foam','C_ex','d_f','theta_c','L_core','RH','w_f','Ra_c'};
p = params_default();
base = zeros(1, numel(names));
for k = 1:numel(names), base(k) = p.(names{k}); end
if strcmpi(mode, 'wide')
    lo = [0.08, 0.40, 0.70,  3, 0.030,  30, 13e-6,  40, 0.010, 0.30, 0.60,   68];
    hi = [0.22, 0.80, 0.90, 10, 0.060, 300, 24e-6, 100, 0.030, 0.70, 0.70, 1088];
else
    lo = 0.75 * base; hi = 1.25 * base;
    k = find(strcmp(names, 'eps_a')); hi(k) = min(hi(k), 0.95);
    k = find(strcmp(names, 'RH'));    hi(k) = min(hi(k), 0.95);
    k = find(strcmp(names, 'w_f'));   hi(k) = min(hi(k), 0.80);
end
end
