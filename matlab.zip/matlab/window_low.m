function Tmin = window_low(p, t_hold)
%WINDOW_LOW  Lowest hold temperature (integer deg C) giving alpha >= p.alpha_req
%after a ramp at p.beta_ramp and an isothermal hold of t_hold seconds.
Tmin = NaN;
for Tc = 300:1:500
    al = pyrolysis_conversion(p, Tc + 273.15, t_hold);
    if al(end) >= p.alpha_req, Tmin = Tc; return; end
end
end
