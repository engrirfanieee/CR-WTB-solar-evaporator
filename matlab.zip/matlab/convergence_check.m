%CONVERGENCE_CHECK  5000-sample Monte Carlo convergence check of the
%recommended design with the 'wide' ranges (Section 4.6). Writes
%convergence_results.txt. The sample stream depends on the random-number
%generator of the software used (see README); the reported values were
%generated with GNU Octave 8.4.
p = params_default();
dRr = optimise_combined(p);
rand('state', 7); N = 5000; [nm, lo, hi] = mc_ranges('wide');
X = lo + (hi - lo) .* rand(N, numel(lo));
Y = zeros(N, 1); dry = false(N, 1); cry = dry; gyp = dry;
for n = 1:N
    pp = p; for k = 1:numel(nm), pp.(nm{k}) = X(n, k); end
    dd = evaluate_design(pp, dRr.d_ch, dRr.s_sp);
    Y(n) = dd.m_net_h; dry(n) = dd.dry; cry(n) = dd.sd.crystallises; gyp(n) = dd.sd.gypsum;
end
ok = ~dry & ~cry; Yk = sort(Y(ok)); Nk = numel(Yk); q = @(f) Yk(max(1, round(f*Nk)));
fid = fopen('convergence_results.txt', 'w');
for f = [1 fid]
    fprintf(f, 'CONV N=5000: dry %.1f%%, NaCl among wetted %.1f%%, gypsum onset among wetted %.1f%%, median %.3f P5 %.3f P95 %.3f kg/m2/h\n', ...
        100*mean(dry), 100*sum(cry & ~dry)/sum(~dry), 100*sum(gyp & ~dry)/sum(~dry), q(.5), q(.05), q(.95));
end
fclose(fid);
