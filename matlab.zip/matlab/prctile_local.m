function v = prctile_local(x, f)
%PRCTILE_LOCAL  Simple percentile (fraction f in 0..1) without toolboxes.
x = sort(x(:)); v = x(max(1, round(f * numel(x))));
end
