function w = solar_weights(p, lam)
%SOLAR_WEIGHTS  Normalised solar spectral weights on the wavelength grid lam [m].
%   p.spectrum = 'AM15G': ASTM G173-03 global-tilt spectrum (am15g.csv, columns:
%   wavelength [nm], irradiance [W m^-2 nm^-1], 300-2500 nm).
%   p.spectrum = 'BB'   : blackbody at p.T_sun.
persistent G
if strcmpi(p.spectrum, 'AM15G')
    if isempty(G), G = dlmread('am15g.csv', ','); end
    w = interp1(G(:,1) * 1e-9, G(:,2), lam, 'linear', 0);
else
    h = 6.62607015e-34; cl = 2.99792458e8; kB = 1.380649e-23;
    w = (2*h*cl^2 ./ lam.^5) ./ (exp(h*cl ./ (lam*kB*p.T_sun)) - 1);
end
w = w / trapz(lam, w);
end
